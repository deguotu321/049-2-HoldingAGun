﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using Exiled.API.Features;
using Exiled.API.Interfaces;
using Exiled.API.Enums;
using Exiled.Events.EventArgs.Player;
using Exiled.Events.EventArgs.Server;
using MEC;
using PlayerRoles;
using UnityEngine;

namespace SCP682Plugin
{
    public class SCP682 : Plugin<SCP682Config>
    {
        public override string Author => "YourName";
        public override string Name => "SCP-682 Hard to Destroy Reptile";
        public override Version Version => new Version(2, 3, 0);
        public override Version RequiredExiledVersion => new Version(8, 9, 11);

        public static SCP682 Instance { get; private set; }
        private CoroutineHandle _682Coroutine;
        private CoroutineHandle _hintCoroutine;
        private Player _scp682Player;
        private int _resurrectionCount = 0;
        private Vector3 _lastDeathPosition;
        private List<string> _deathQuotes = new List<string>
        {
            "OBJECT CLASS: APOLLYON",
            "THIS WILL NOT CONTAIN ME",
            "ADAPTING... EVOLVING...",
            "I HATE YOU ALL",
            "YOUR PUNY WEAPONS ARE USELESS",
            "I AM ETERNAL",
            "THE FOUNDATION WILL FALL",
            "MORTALS CANNOT COMPREHEND MY EXISTENCE",
            "DEATH IS BUT A TEMPORARY INCONVENIENCE",
            "I SHALL DEVOUR YOUR WORLD"
        };

        public override void OnEnabled()
        {
            Instance = this;
            Exiled.Events.Handlers.Server.RoundStarted += OnRoundStarted;
            Exiled.Events.Handlers.Player.Died += OnPlayerDied;
            Exiled.Events.Handlers.Server.RestartingRound += OnRoundRestarting;
            base.OnEnabled();
        }

        public override void OnDisabled()
        {
            Exiled.Events.Handlers.Server.RoundStarted -= OnRoundStarted;
            Exiled.Events.Handlers.Player.Died -= OnPlayerDied;
            Exiled.Events.Handlers.Server.RestartingRound -= OnRoundRestarting;

            if (_682Coroutine.IsRunning)
                Timing.KillCoroutines(_682Coroutine);

            if (_hintCoroutine.IsRunning)
                Timing.KillCoroutines(_hintCoroutine);

            Instance = null;
            base.OnDisabled();
        }

        private void OnRoundStarted()
        {
            _resurrectionCount = 0;

            // 随机选择一个SCP玩家作为SCP-682
            var scpPlayers = Player.Get(Team.SCPs).ToList();
            if (scpPlayers.Count == 0)
            {
                if (Config.Debug)
                    Log.Debug("没有SCP玩家，无法生成SCP-682");
                return;
            }

            _scp682Player = scpPlayers[UnityEngine.Random.Range(0, scpPlayers.Count)];
            SpawnSCP682();

            // 全服广播
            Map.Broadcast(10,
                "<size=35><color=#ff0000>███ 紧急通告 ███</color></size>\n" +
                "<color=#ff6666>SCP-682 '憎恨之血肉' 已突破收容！</color>\n" +
                $"<color=orange>{_scp682Player.Nickname}</color> 已被实体占据\n" +
                "<size=20><color=#aaaaaa>MTF-Epsilon11 '九尾狐' 已部署至设施</color></size>",
                Broadcast.BroadcastFlags.Normal);

            if (Config.Debug)
                Log.Debug($"SCP-682已生成在 {_scp682Player.Nickname} 身上");
        }

        private void SpawnSCP682()
        {
            // 设置SCP-682属性
            _scp682Player.Role.Set(RoleTypeId.Scp939);

            // 计算当前属性
            float currentScale = Config.InitialScale * (1 + Config.ScaleIncrease * _resurrectionCount);
            float currentSpeed = Config.InitialSpeed * (1 + Config.SpeedIncrease * _resurrectionCount);
            int currentHealth = (int)(Config.InitialHealth * Math.Pow(Config.HealthMultiplier, _resurrectionCount));
            int currentDrain = (int)(Config.HealthDrainPerSecond * Math.Pow(Config.DrainMultiplier, _resurrectionCount));

            // 应用属性
            _scp682Player.Scale = new Vector3(currentScale, currentScale, currentScale);
            _scp682Player.Health = currentHealth;
            _scp682Player.MaxHealth = currentHealth;

            // 设置移动速度
            _scp682Player.EnableEffect(EffectType.MovementBoost, 10000);
            _scp682Player.ChangeEffectIntensity(EffectType.MovementBoost, (byte)(currentSpeed * 100));

            // 设置自定义信息
            _scp682Player.CustomInfo = $"<color=#ff3300>SCP-682</color> (形态 {_resurrectionCount + 1}/{Config.MaxResurrections + 1})";
            _scp682Player.RankColor = "red";
            _scp682Player.RankName = "SCP-682";

            // 开始扣血协程
            if (_682Coroutine.IsRunning)
                Timing.KillCoroutines(_682Coroutine);

            _682Coroutine = Timing.RunCoroutine(DrainHealth(currentDrain));

            // 启动提示协程
            if (_hintCoroutine.IsRunning)
                Timing.KillCoroutines(_hintCoroutine);
            _hintCoroutine = Timing.RunCoroutine(ShowAbilityHints());

            // 形态特殊能力提示
            string evolutionMessage = GetEvolutionMessage();
            Map.Broadcast(8,
                $"<size=30><color=#ff6666>憎恨之血肉 进化至形态 {_resurrectionCount + 1}</color></size>\n" +
                $"{evolutionMessage}\n" +
                $"<size=20><color=#ff9999>HP: {currentHealth} | 速度: {currentSpeed:P0} | 体型: {currentScale:F1}x</color></size>",
                Broadcast.BroadcastFlags.Normal);

            // 给SCP-682玩家的私人提示
            _scp682Player.ShowHint(
                $"<size=35><color=red>你已成为 SCP-682</color></size>\n" +
                $"<color=orange>{GetLoreDescription()}</color>\n\n" +
                "<size=25><color=#aaaaaa>能力特性:</color></size>\n" +
                $"• <color=yellow>进化形态</color>: {_resurrectionCount + 1}/{Config.MaxResurrections + 1}\n" +
                $"• <color=yellow>生命侵蚀</color>: -{currentDrain} HP/秒\n" +
                $"• <color=yellow>憎恨光环</color>: 附近玩家持续受伤\n" +
                $"• <color=yellow>自适应外壳</color>: 减少所有伤害 {_resurrectionCount * 5}%\n\n" +
                "<size=20><color=#ff6666>你的存在就是对生命本身的亵渎</color></size>",
                15);
        }

        private string GetLoreDescription()
        {
            string[] descriptions = {
                "仇恨所有生命形态的古老爬行生物，基金会无法摧毁的不朽存在",
                "适应性极强的爬行类实体，会因受到的伤害而不断进化",
                "Keter级实体，已记录超过400次收容失效事件",
                "对生命充满憎恨，会主动攻击所有有机生命体",
                "基金会记录中最难摧毁的实体，没有之一"
            };
            return descriptions[UnityEngine.Random.Range(0, descriptions.Length)];
        }

        private string GetEvolutionMessage()
        {
            switch (_resurrectionCount)
            {
                case 0:
                    return "<color=#66ff66>初始形态</color>: 体型较小，移动速度较慢";
                case 1:
                    return "<color=#ffcc00>硬化甲壳</color>: 移动速度增加，体型增大";
                case 2:
                    return "<color=#ff9966>掠食者形态</color>: 显著增加攻击性，速度大幅提升";
                case 3:
                    return "<color=#ff6600>狂暴阶段</color>: 体型增大50%，获得伤害抵抗";
                case int n when n >= 4 && n <= 6:
                    return $"<color=#ff3300>憎恨形态 {n - 2}</color>: 持续伤害光环扩大，体型增大";
                case int n when n > 6:
                    return $"<color=#cc0000>终焉形态 {n - 5}</color>: 接近完全体，毁灭性的存在";
                default:
                    return "适应性进化激活";
            }
        }

        private IEnumerator<float> ShowAbilityHints()
        {
            int hintIndex = 0;
            var abilityHints = new List<string>
            {
                "<color=red>憎恨光环</color>: 10米范围内所有生物持续受伤",
                "<color=red>酸性血液</color>: 攻击你的敌人会受到腐蚀伤害",
                "<color=red>再生因子</color>: 脱离战斗后生命值会缓慢恢复",
                "<color=red>形态进化</color>: 每次死亡都会使你变得更强大",
                "<color=red>破坏欲望</color>: 对建筑和机械造成额外伤害"
            };

            while (true)
            {
                if (_scp682Player != null && _scp682Player.IsAlive)
                {
                    // 显示当前状态提示
                    string hint = $"<size=25><color=#ff3300>SCP-682 形态 {_resurrectionCount + 1}</color></size>\n" +
                                  $"<color=orange>HP: {_scp682Player.Health}/{_scp682Player.MaxHealth}</color> | " +
                                  $"<color=#66ff66>速度: {_scp682Player.GetEffect(EffectType.MovementBoost).Intensity * 100}%</color>\n" +
                                  $"<size=20>{abilityHints[hintIndex]}</size>";

                    _scp682Player.ShowHint(hint, 3.5f);

                    hintIndex = (hintIndex + 1) % abilityHints.Count;
                }

                yield return Timing.WaitForSeconds(8f);
            }
        }

        private IEnumerator<float> DrainHealth(int drainAmount)
        {
            while (true)
            {
                yield return Timing.WaitForSeconds(1f);

                if (_scp682Player == null || !_scp682Player.IsAlive)
                    yield break;

                _scp682Player.Health -= drainAmount;

                // 对附近玩家造成伤害
                foreach (Player player in Player.List)
                {
                    if (player != _scp682Player &&
                        player.IsAlive &&
                        Vector3.Distance(_scp682Player.Position, player.Position) < 10f)
                    {
                        player.Hurt(5, DamageType.Poison, "SCP-682 憎恨光环");
                        player.ShowHint($"<color=red>受到SCP-682憎恨光环影响!</color>", 1.5f);
                    }
                }

                if (_scp682Player.Health <= 0)
                {
                    string deathQuote = _deathQuotes[UnityEngine.Random.Range(0, _deathQuotes.Count)];
                    _scp682Player.Kill($"<color=red>{deathQuote}</color>");
                    yield break;
                }
            }
        }

        private void OnPlayerDied(DiedEventArgs ev)
        {
            if (ev.Player != _scp682Player)
                return;

            _lastDeathPosition = ev.Player.Position;

            string deathMessage =
                $"<size=25><color=red>SCP-682 暂时失效</color></size>\n" +
                $"<color=orange>形态 {_resurrectionCount + 1} 被摧毁</color>\n" +
                $"<size=20>适应进程: {UnityEngine.Random.Range(45, 85)}%</size>";

            Map.Broadcast(5, deathMessage, Broadcast.BroadcastFlags.Normal);

            if (_resurrectionCount >= Config.MaxResurrections)
            {
                Map.Broadcast(12,
                    "<size=35><color=green>███ 收容成功 ███</color></size>\n" +
                    "<color=#66ff66>SCP-682 已被永久收容!</color>\n" +
                    $"<size=25>终结者: {ev.Attacker?.Nickname ?? "未知"}</size>\n" +
                    "<size=20><i>\"我们控制，我们收容，我们保护\"</i></size>",
                    Broadcast.BroadcastFlags.Normal);

                _scp682Player = null;
                return;
            }

            _resurrectionCount++;

            Timing.CallDelayed(Config.ResurrectionDelay, () =>
            {
                if (_scp682Player == null)
                    return;

                // 复活SCP-682
                _scp682Player.Role.Set(RoleTypeId.Spectator);
                Timing.CallDelayed(0.5f, () =>
                {
                    _scp682Player.Position = _lastDeathPosition;
                    SpawnSCP682();

                    // 复活特效
                    _scp682Player.EnableEffect(EffectType.Flashed, 0.5f);
                    _scp682Player.EnableEffect(EffectType.BodyshotReduction, 2f);

                    // 短暂无敌时间
                    _scp682Player.IsGodModeEnabled = true;
                    Timing.CallDelayed(2f, () => _scp682Player.IsGodModeEnabled = false);
                });
            });
        }

        private void OnRoundRestarting()
        {
            if (_scp682Player != null)
            {
                _scp682Player.ShowHint(
                    "<size=30><color=red>SCP-682 日志</color></size>\n" +
                    $"<color=orange>最终形态: {_resurrectionCount + 1}</color>\n" +
                    "<size=20><i>\"我终将回归...\"</i></size>",
                    5);
            }

            _scp682Player = null;
            _resurrectionCount = 0;

            if (_682Coroutine.IsRunning)
                Timing.KillCoroutines(_682Coroutine);

            if (_hintCoroutine.IsRunning)
                Timing.KillCoroutines(_hintCoroutine);
        }
    }

    public class SCP682Config : IConfig
    {
        [Description("是否启用插件")]
        public bool IsEnabled { get; set; } = true;

        [Description("是否启用调试模式")]
        public bool Debug { get; set; } = false;

        [Description("SCP-682初始血量")]
        public int InitialHealth { get; set; } = 200;

        [Description("初始模型大小比例 (0-1)")]
        public float InitialScale { get; set; } = 0.3f;

        [Description("初始移动速度比例 (0-1)")]
        public float InitialSpeed { get; set; } = 0.3f;

        [Description("每秒扣除的生命值")]
        public int HealthDrainPerSecond { get; set; } = 2;

        [Description("复活前不能移动的时间(秒)")]
        public float ResurrectionDelay { get; set; } = 5f;

        [Description("最大复活次数")]
        public int MaxResurrections { get; set; } = 10;

        [Description("每次复活血量乘数")]
        public float HealthMultiplier { get; set; } = 2f;

        [Description("每次复活扣血乘数")]
        public float DrainMultiplier { get; set; } = 2f;

        [Description("每次复活速度增加比例")]
        public float SpeedIncrease { get; set; } = 0.1f;

        [Description("每次复活大小增加比例")]
        public float ScaleIncrease { get; set; } = 0.05f;

        [Description("憎恨光环伤害")]
        public int AuraDamage { get; set; } = 5;

        [Description("憎恨光环范围")]
        public float AuraRange { get; set; } = 10f;
    }
}